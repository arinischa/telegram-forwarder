# Forwarder Bot
Deploy to Railway and set TOKEN + CHANNEL_ID.